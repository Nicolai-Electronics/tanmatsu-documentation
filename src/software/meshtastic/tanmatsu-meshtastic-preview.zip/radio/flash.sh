#!/usr/bin/env bash

esptool.py --chip esp32c6 erase_flash
esptool.py --chip esp32c6 write_flash 0x0 bootloader.bin 0x10000 firmware.bin 0x8000 partitions.bin
