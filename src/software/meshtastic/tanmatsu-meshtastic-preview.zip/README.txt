To install the GUI app first switch to BadgeLink mode, then run:

python badgelink.py appfs upload meshtastic "Meshtastic" 0 meshtastic-gui.bin

To install the radio firmware run:

esptool.py --chip esp32c6 erase_flash
esptool.py --chip esp32c6 write_flash 0x0 radio/bootloader.bin 0x10000 radio/firmware.bin 0x8000 radio/partitions.bin

----

Sources:

https://github.com/nicolai-electronics/tanmatsu-meshtastic-radio
https://github.com/nicolai-electronics/tanmatsu-meshtastic-ui

License:

GNU GPL v3.0
